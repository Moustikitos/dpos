# -*- coding: utf-8 -*-

"""
ASLP transaction builders. See [ASLP API](https://aslp.qredit.dev) for more
information.

  - ASLP1 token is an ERC20-equivalent-smartbridge-embeded token.
  - ASLP2 token is an NFT-equivalent-smartbridge-embeded token.

```python
>>> t = dposlib.core.aslpGenesis(
...    2, "TTK", "Toon's token", 250000,
...    du="ipfs://bafkreigfxalrf52xm5ecn4lorfhiocw4x5cxpktnkiq3atq6jp2elktobq",
...    no="For testing purpose only.", pa=True, mi=True
... )
>>> t.vendorField
'{"aslp1":{"tp":"GENESIS","de":"2","sy":"TTK","na":"Toon\'s token","qt":"25000'
'000","du":"ipfs://bafkreigfxalrf52xm5ecn4lorfhiocw4x5cxpktnkiq3atq6jp2elktobq'
'","no":"For testing purpose only."}}'
>>>
>>> t.finalize("secret passphrase")
>>> print(t)
{
  "version": 2,
  "amount": 100000000,
  "asset": {},
  "fee": 5000000,
  "id": "ff2c7e5300a1457b289ced0644ec36fe073958d01d2b2b9976dbcff21064781b",
  "network": 23,
  "nonce": 1,
  "recipientId": "ARKQXzHvEWXgfCgAcJWJQKUMus5uE6Yckr",
  "senderId": "AdzCBJt2F2Q2RYL7vnp96QhTeGdDZNZGeJ",
  "senderPublicKey":
    "03aacac6c98daaf3d433fe90e9295ce380916946f850bcdc6f6880ae6503ca1e40",
  "signature":
    "fa754a2966d44197c08093263e8a1287fce7ab0c05dcccc4e0f7a0f00a1a781527d911629"
    "c67c58dea6873d8841e37c1057d247813b06e47cf3b59033ed7bc91",
  "timestamp": 147979327,
  "type": 0,
  "typeGroup": 1,
  "vendorField":
    "{\"aslp1\":{\"tp\":\"GENESIS\",\"de\":\"2\",\"sy\":\"TTK\",\"na\":\"Toon'"
    "s token\",\"qt\":\"25000000\",\"du\":\"ipfs://bafkreigfxalrf52xm5ecn4lorf"
    "hiocw4x5cxpktnkiq3atq6jp2elktobq\",\"no\":\"For testing purpose only.\"}}"
}
>>> dposlib.core.broadcastTransactions(t)
{
  'data': {
    'accept': [],
    'broadcast': [],
    'excess': [],
    'invalid': [
      'ff2c7e5300a1457b289ced0644ec36fe073958d01d2b2b9976dbcff21064781b'
    ]
  }, 'errors': {
    'ff2c7e5300a1457b289ced0644ec36fe073958d01d2b2b9976dbcff21064781b': {
      'type': 'ERR_APPLY',
      'message':
        'AdzCBJt2F2Q2RYL7vnp96QhTeGdDZNZGeJ#1 1064781b Transfer v2 cannot be a'
        'pplied: Insufficient balance in the wallet.'
    }
  },
  'status': 200
}
```
"""

import json

from dposlib import cfg
from dposlib.ark.tx import Transaction
from dposlib.aslp.api import GET


def aslpGenesis(de, sy, na, qt, du=None, no=None, pa=False, mi=False):
    """
    Build a aslp1 genesis transaction.

    Args:
        de (int): decimal number.
        sy (str): token symbol.
        na (str): token name.
        qt (int): maximum supply.
        du (str): document URI.
        no (str): token notes.
        pa (bool): pausable token ?
        mi (bool): mintable token ?

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp1
            `vendorField`.
    """
    args = dict(decimals=de, symbol=sy, name=na, quantity=qt)
    if du:
        args["uri"] = du
    if no:
        args["notes"] = no[:32]
    if pa:
        args["pausable"] = "true"
    if mi:
        args["mintable"] = "true"

    smartbridge = GET.api.vendor_aslp1_genesis(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=100000000,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslpBurn(tkid, qt, no=None):
    """
    Build a aslp1 burn transaction.

    Args:
        tkid (str): token id.
        qt (int): quantity to burn.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp1
            `vendorField`.
    """
    args = dict(tokenid=tkid, quantity=qt)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp1_burn(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslpMint(tkid, qt, no=None):
    """
    Build a aslp1 mint transaction.

    Args:
        tkid (str): token id.
        qt (int): quantity to burn.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp1
            `vendorField`.
    """
    args = dict(tokenid=tkid, quantity=qt)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp1_mint(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslpSend(address, tkid, qt, no=None):
    """
    Build a aslp1 send transaction.

    Args:
        address (str): recipient wallet address.
        tkid (str): token id.
        qt (int): quantity to burn.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp1
            `vendorField`.
    """
    args = dict(tokenid=tkid, quantity=qt)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp1_send(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslpPause(tkid, no=None):
    """
    Build a aslp1 pause transaction.

    Args:
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp1
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp1_pause(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslpResume(tkid, no=None):
    """
    Build a aslp1 resume transaction.

    Args:
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp1
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp1_resume(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslpNewOwner(address, tkid, no=None):
    """
    Build a aslp1 owner change transaction.

    Args:
        address (str): new owner wallet address.
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp1
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp1_newowner(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslpFreeze(address, tkid, no=None):
    """
    Build a aslp1 freeze transaction.

    Args:
        address (str): frozen wallet address.
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp1
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp1_freeze(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslpUnFreeze(address, tkid, no=None):
    """
    Build a aslp1 unfreeze transaction.

    Args:
        address (str): unfrozen wallet address.
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp1
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp1_unfreeze(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslp2Genesis(sy, na, du=None, no=None, pa=False):
    """
    Build a aslp2 genesis transaction.

    Args:
        sy (str): token symbol.
        na (str): token name.
        du (str): URI.
        no (str): token notes.
        pa (bool): pausable token ?

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp2
            `vendorField`.
    """
    args = dict(symbol=sy, name=na)
    if du:
        args["uri"] = du
    if no:
        args["notes"] = no[:32]
    if pa:
        args["pausable"] = "true"

    smartbridge = GET.api.vendor_aslp2_genesis(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=100000000,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslp2Pause(tkid, no=None):
    """
    Build a aslp2 pause transaction.

    Args:
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp2
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp2_pause(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslp2Resume(tkid, no=None):
    """
    Build a aslp2 resume transaction.

    Args:
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp2
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp2_resume(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslp2NewOwner(address, tkid, no=None):
    """
    Build a aslp2 owner change transaction.

    Args:
        address (str): new owner wallet address.
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp2
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp2_newowner(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslp2AuthMeta(address, tkid, no=None):
    """
    Build a aslp2 meta change authorization transaction.

    Args:
        address (str): authorized wallet address.
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp2
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp2_authmeta(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslp2RevokeMeta(address, tkid, no=None):
    """
    Build a aslp2 meta change revokation transaction.

    Args:
        address (str): revoked wallet address.
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp2
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp2_revokemeta(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslp2Clone(tkid, no=None):
    """
    Build a aslp2 clone transaction.

    Args:
        tkid (str): token id.
        no (str): token notes.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp2
            `vendorField`.
    """
    args = dict(tokenid=tkid)
    if no:
        args["notes"] = no[:32]

    smartbridge = GET.api.vendor_aslp2_clone(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslp2AddMeta(tkid, na, dt, ch=None):
    """
    Build a aslp2 metadata edition transaction.

    Args:
        tkid (str): token id.
        na (str): name of the metadata info.
        dt (str): data of metadata.
        ch (int): chunk number.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp2
            `vendorField`.
    """
    args = dict(tokenid=tkid, name=na, data=dt)
    if ch:
        args["chunk"] = ch

    smartbridge = GET.api.vendor_aslp2_addmeta(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


def aslp2VoidMeta(tkid, tx):
    """
    Build a aslp2 metadata cleaning transaction.

    Args:
        tkid (str): token id.
        tx (str): transaction id of metadata to void.

    Returns:
        dposlib.ark.tx.Transaction: orphan transaction with appropriate aslp2
            `vendorField`.
    """
    args = dict(tokenid=tkid, txid=tx)

    smartbridge = GET.api.vendor_aslp2_voidmeta(**args)
    if smartbridge.pop("status", 0) != 200:
        raise Exception(smartbridge.get("error", "aslp smartbridge error"))

    return Transaction(
        typeGroup=1,
        type=0,
        amount=1,
        recipientId=cfg.master_address,
        vendorField=json.dumps(smartbridge, separators=(",", ":"))
    )


__all__ = [
    aslpGenesis, aslpBurn, aslpMint, aslpSend, aslpPause, aslpResume,
    aslpNewOwner, aslpFreeze, aslpUnFreeze,
    aslp2Genesis, aslp2Pause, aslp2Resume,
    aslp2NewOwner, aslp2AuthMeta, aslp2RevokeMeta,
    aslp2Clone, aslp2AddMeta, aslp2VoidMeta
]
